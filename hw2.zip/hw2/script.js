let btn = document.getElementById('get') 
let root = document.getElementById('root') 
btn.addEventListener('click', function(event) { 
let id = document.getElementById('title').value 
event.preventDefault() 
fetch(`https://jsonplaceholder.typicode.com/users/${id}`).then((response) =>{ 
    console.log(response); 
    return response.json() 
}).then((data) => { 
    console.log(data); 
    root.innerHTML += `<div class="card"> 
    <h3>Name:${data.name}</h3><h3>Username:${data.username}</h3><h3>Phone:${data.phone}</h3></div>` 
})
})